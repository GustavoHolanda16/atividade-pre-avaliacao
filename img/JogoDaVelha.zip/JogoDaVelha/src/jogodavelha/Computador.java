/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package jogodavelha;

/**
 *
 * @author home
 */
public class Computador extends Jogador{
    
    public Computador(int jogador){
        super(jogador);
        System.out.println("Jogador 'Computador' criado!");
    }
    
    @Override
    public void jogar(Tabuleiro tabuleiro){
        
    }
    
    @Override
    public void Tentativa(Tabuleiro tabuleiro){
        
    }
}