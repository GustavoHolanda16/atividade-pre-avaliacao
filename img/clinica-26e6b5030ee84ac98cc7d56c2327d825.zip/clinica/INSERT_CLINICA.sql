﻿-- TABELA AMBULATÓRIOS
INSERT INTO tb_ambulatorios (ambandar, ambcapacidade) VALUES (1, 30);
INSERT INTO tb_ambulatorios (ambandar, ambcapacidade) VALUES (1, 50);
INSERT INTO tb_ambulatorios (ambandar, ambcapacidade) VALUES (2, 40);
INSERT INTO tb_ambulatorios (ambandar, ambcapacidade) VALUES (2, 25);
INSERT INTO tb_ambulatorios (ambandar, ambcapacidade) VALUES (2, 55);

-- TABELA MÉDICOS
INSERT INTO tb_medicos (mednome, meddatanasc, medespecialidade, medcpf, medcidade, ambnum) VALUES ('João', '1977-10-08', 'Ortopedia', '12345678910', 'Teresina', 1);
INSERT INTO tb_medicos (mednome, meddatanasc, medespecialidade, medcpf, medcidade, ambnum) VALUES ('Maria', '1975-06-30', 'Traumatologia', '98745612345', 'Picos', 2);
INSERT INTO tb_medicos (mednome, meddatanasc, medespecialidade, medcpf, medcidade, ambnum) VALUES ('Pedro', '1966-09-19', 'Pediatria', '19812356782', 'Floriano', 2);
INSERT INTO tb_medicos (mednome, meddatanasc, medespecialidade, medcpf, medcidade) VALUES ('Carlos', '1989-04-01', 'Neurologia', '11294586792', 'Barras');
INSERT INTO tb_medicos (mednome, meddatanasc, medespecialidade, medcpf, medcidade, ambnum) VALUES ('Marcia', '1984-01-22', 'Neurologia', '98798612345', 'Bom Jesus', 3);
INSERT INTO tb_medicos (mednome, meddatanasc, medespecialidade, medcpf, medcidade, ambnum) VALUES ('Eduardo', '1992-06-04', 'Pediatria', '13379438863', 'Picos',5);
INSERT INTO tb_medicos (mednome, meddatanasc, medespecialidade, medcpf, medcidade, ambnum) VALUES ('Ycaro', '1992-11-11', 'Traumatologia', '48665671129', 'Floriano', 5);

-- TABELA DEPARTAMENTOS
INSERT INTO tb_departamentos (depnome) VALUES ('Contabil');
INSERT INTO tb_departamentos (depnome) VALUES ('Limpeza');
INSERT INTO tb_departamentos (depnome) VALUES ('Recursos Humanos');
INSERT INTO tb_departamentos (depnome) VALUES ('TI');

-- TABELA FUNCIONÁRIOS
INSERT INTO tb_funcionarios (funcnome, funcdatanasc, funccidade, funcsalario, funccpf, depcod) VALUES ('Rita', '1985-01-02', 'Floriano', 1200, '20000100000', 2);
INSERT INTO tb_funcionarios (funcnome, funcdatanasc, funccidade, funcsalario, funccpf, depcod) VALUES ('Maria', '1962-05-08', 'Corrente', 3220, '30000110000', 1);
INSERT INTO tb_funcionarios (funcnome, funcdatanasc, funccidade, funcsalario, funccpf, depcod) VALUES ('Caio', '1972-08-18', 'Teresina', 1100, '41000100000', 2);
INSERT INTO tb_funcionarios (funcnome, funcdatanasc, funccidade, funcsalario, funccpf, depcod) VALUES ('Carlos', '1973-11-10', 'Teresina', 2200, '51000110000', 1);
INSERT INTO tb_funcionarios (funcnome, funcdatanasc, funccidade, funcsalario, funccpf, depcod) VALUES ('Paula', '1984-09-19', 'Teresina', 2500, '61000111000', 1);
INSERT INTO tb_funcionarios (funcnome, funcdatanasc, funccidade, funcsalario, funccpf, depcod) VALUES ('Taiane', '1992-04-06', 'Floriano', 2000, '35523213659', 3);
INSERT INTO tb_funcionarios (funcnome, funcdatanasc, funccidade, funcsalario, funccpf, depcod) VALUES ('Tamires', '1994-07-07', 'Teresina', 1800, '94685943600', 3);
INSERT INTO tb_funcionarios (funcnome, funcdatanasc, funccidade, funcsalario, funccpf, depcod) VALUES ('Valdirene', '1977-02-22', 'Teresina', 2500, '46081633454', 3);
INSERT INTO tb_funcionarios (funcnome, funcdatanasc, funccidade, funcsalario, funccpf, depcod) VALUES ('Marlon', '1987-09-08', 'Teresina', 4500, '23283057095', 4);
INSERT INTO tb_funcionarios (funcnome, funcdatanasc, funccidade, funcsalario, funccpf, depcod) VALUES ('Thiago', '1986-01-10', 'Teresina', 4200, '55789638899', 4);
INSERT INTO tb_funcionarios (funcnome, funcdatanasc, funccidade, funcsalario, funccpf, depcod) VALUES ('Mario', '1989-03-28', 'Teresina', 4350, '97906328604', 4);

-- TABELA PACIENTES
INSERT INTO tb_pacientes (pacnome, pacdatanasc, paccidade, paccpf, pacdoenca) VALUES ('Paula', '1984-05-12', 'Teresina', '61000111000', 'Gripe');
INSERT INTO tb_pacientes (pacnome, pacdatanasc, paccidade, paccpf, pacdoenca) VALUES ('João', '1977-09-30', 'Teresina', '12345678910', 'Fratura');
INSERT INTO tb_pacientes (pacnome, pacdatanasc, paccidade, paccpf, pacdoenca) VALUES ('Lucia', '1987-02-02', 'Bom Jesus', '22000200000', 'Tendinite');
INSERT INTO tb_pacientes (pacnome, pacdatanasc, paccidade, paccpf, pacdoenca) VALUES ('Carlos', '1987-06-20', 'Barras', '11000110000', 'Sarampo');
INSERT INTO tb_pacientes (pacnome, pacdatanasc, paccidade, paccpf, pacdoenca) VALUES ('Tamires', '1995-12-25', 'Teresina', '46081633454', 'Febre');
INSERT INTO tb_pacientes (pacnome, pacdatanasc, paccidade, paccpf, pacdoenca) VALUES ('Thiago', '1986-11-10', 'Teresina', '55789638899', 'Renite alérgica');
INSERT INTO tb_pacientes (pacnome, pacdatanasc, paccidade, paccpf, pacdoenca) VALUES ('Maria', '1975-08-06', 'Picos', '98745612345', 'Infecção Intestinal');

-- TABELA CONSULTAS
INSERT INTO tb_consultas (consdata, conshora, paccod, medcod) VALUES ('2015-12-06', '14:00', 1, 1);
INSERT INTO tb_consultas (consdata, conshora, paccod, medcod) VALUES ('2015-12-13', '10:00', 4, 1);
INSERT INTO tb_consultas (consdata, conshora, paccod, medcod) VALUES ('2015-12-13', '09:00', 1, 2);
INSERT INTO tb_consultas (consdata, conshora, paccod, medcod) VALUES ('2015-12-13', '11:00', 2, 2);
INSERT INTO tb_consultas (consdata, conshora, paccod, medcod) VALUES ('2015-12-14', '14:00', 3, 2);
INSERT INTO tb_consultas (consdata, conshora, paccod, medcod) VALUES ('2015-12-14', '17:00', 4, 2);
INSERT INTO tb_consultas (consdata, conshora, paccod, medcod) VALUES ('2015-12-19', '18:00', 1, 3);
INSERT INTO tb_consultas (consdata, conshora, paccod, medcod) VALUES ('2015-12-12', '10:00', 3, 3);
INSERT INTO tb_consultas (consdata, conshora, paccod, medcod) VALUES ('2015-12-19', '13:00', 4, 3);
INSERT INTO tb_consultas (consdata, conshora, paccod, medcod) VALUES ('2015-12-20', '13:00', 4, 4);
INSERT INTO tb_consultas (consdata, conshora, paccod, medcod) VALUES ('2015-12-20', '19:30', 4, 4);